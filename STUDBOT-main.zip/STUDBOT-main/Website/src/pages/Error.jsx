const Error = () => {
  return (
    <div className="text-3xl text-white mx-auto my-auto">
      Error - 404 Not found
    </div>
  );
};

export default Error;
